/*
Jaskeerat Randhawa
// 02/13/2024
//100901805
// JS code for ice 4 functianlity
*/

// create and append the nav bar
const body = document.body;
let html = '<nav id="navbar" class="navbar fixed navbar-expand-lg navbar-light bg-primary" >' +
    '<ul class="navbar-nav">' +
    '<li class="nav-item"><a class="nav-link" href="./index.html">Home</a></li>' +
    '<li class="nav-item"><a class="nav-link" href="./slideshow.html">Slideshow</a></li>' +
    '<li class="nav-item"><a class="nav-link" href="./form.html">contact</a></li>' +
    
    '</ul></nav>';
body.insertAdjacentHTML("afterbegin", html);

const navbar = document.getElementById('navbar');

/**
 * function to add styling to all links on the page
 */
console.log("yes")
/**
 * fuction to demo adding content with .text() and .html()
 *  */

// function will add the text given using .txt() and .html()
$(function () {

    let navDiv = $("div:first");
     console.log(navDiv.html())
     console.log(navDiv.text())

 let contentDiv = $("#content-div");
    console.log(contentDiv.html())
     console.log(contentDiv.text())

    // text to use with new paragraph
    let text = "It is one of his best works!";
    // create a paragraph
     let newP = $("<p></p>");
    // TO DO: add text with html()
    newP.html(text);
    contentDiv.append(newP);


    // append to contentDiv

    // add text
    newP.html("I am <strong>very excited</strong> for the opening of the new adaptation of his work.");    
    contentDiv.append(newP);
    // TO DO: append to newP text

});

/**
 * function to demo adding toggle to button
 *  */
$(function () {
    // TO DO: complete the function
    // get the button 
    let theButton = $("#toggleButton"); 

    theButton.on("click", () => {
        let parentDiv = $("#toggleDiv");
        let paragraphs = parentDiv.find("p");

        paragraphs.each(function () {
            let paragraph = $(this);

            if (paragraph.hasClass("toggleHide")) {
                paragraph.removeClass("toggleHide").addClass("toggleShow");
            } else {
                paragraph.removeClass("toggleShow").addClass("toggleHide");
            }
        });
    });
});

// FORM JQUERY
// TO DO: import form validation functions with alias

// if the submit button is on the page
if ($("#btnRegSubmit")) {
    let theButton = $("#btnRegSubmit");
    // TO DO: add a click function that calls a callack function
    theButton.on("click", () => {
        // prevent the default submit action (stay on the page)

        // create a new user
        // you normally wouldn't do this unless you had validated, but we're going to do it to show how class memebers work in calling the validation
        let newUser = new User(firstNameInput, lastNameInput, usernameInput, emailInput, passwordInput);

        // Debug statement for object

            // get the first name input
        let firstNameInput = $("#inputFirst").val();

            // get the last name input
        let lastNameInput = $("#inputLast").val();

            // get the username input
        let usernameInput = $("#inputUsername").val();

            // get the email input
        let emailInput = $("#inputEmail").val();

            // get the password input

        let passwordInput = $("#inputPassword").val();
        let confirmPasswordInput = $("#inputPassword2").val();


        // debug statement for 
        console.log(`UserDetails: ${newUser.displayUser()}`);

        let firstError = validateFirst(firstNameInput);
        let lastError = validateLast(lastNameInput);
        let usernameError = validateUsername(usernameInput);

        // validate first name
        
        // validate last name

        // validate  username

       // clear all of the error messages 
        clearErrorMessages();
    });
}

// If the reset button is present
if ($("#btnReset")) {
    let resetButton = $("#btnReset");

    // Bind a click event handler
    resetButton.on("click", () => {
        // Clear out all error messages
        clearErrorMessages();
    });
}

/**
 * Function to clear out all error messages
 */
function clearErrorMessages() {
    $(".error-message").remove();
}

    // call a callback function to handle the galler rotation

function rotateGallery(images, currentIndex) {
    // create a jQuery object for the image tag
    let galleryImage = $("<img>");

    // set a first index
    currentIndex = currentIndex = 1;

    // append the initial image to the body
    $("#gallery-box").append(galleryImage);

    // call the setInterval method that will re-call this method at a set interval
    setInterval(function () {
        // increment the image index but not bigger than the length of the image array
        currentIndex = (currentIndex + 1) % images.length;

        // fade out the current image
        galleryImage.fadeOut(1000, function () {
            console.log(`Image changed to: ${images[currentIndex]}`);

            // set the src  of the existing image to the new image
            galleryImage.attr("src", images[currentIndex]);

            // fade in the existing image
            galleryImage.fadeIn(1000);
        });

        // set the time for more than how long the fade out and fade in process will take
    }, 3000);
}


let imageArray = [
    "./images/portraits/portrait-01.jpg",
    "./images/portraits/portrait-02.jpg",
    "./images/portraits/portrait-03.jpg",
    "./images/portraits/portrait-04.jpg",
    "./images/portraits/portrait-05.jpg",
    "./images/portraits/portrait-06.jpg",
    "./images/portraits/portrait-07.jpg",
    "./images/portraits/portrait-08.jpg",
    "./images/portraits/portrait-09.jpg",
    "./images/portraits/portrait-10.jpg",
    "./images/portraits/portrait-11.jpg",
    "./images/portraits/portrait-12.jpg",
    "./images/portraits/portrait-13.jpg",
    "./images/portraits/portrait-14.jpg",
    "./images/portraits/portrait-15.jpg",
    "./images/portraits/portrait-16.jpg",
    "./images/portraits/portrait-17.jpg",
    "./images/portraits/portrait-18.jpg",
    "./images/portraits/portrait-19.jpg"
];

rotateGallery(imageArray, 0);
